# Kimnd.github.io
An attempt at making a website.
